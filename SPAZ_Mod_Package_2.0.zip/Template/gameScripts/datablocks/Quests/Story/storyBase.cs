//Story Base

//These can be of any questType, (except ambient cuz that is dumb)
//Define a mission to be story by setting its rarity to "Story";
//Story quests will push out quest out of instances so they can fire.
//questType   = "Event", "Inf", "Sec";
//rarity = "Story";


