//Loaded after all non gameplay scripts execute.
$LoadingTitle = "Template Mod Art";
$LoadingCount = 1;  //Divide line count by 20

//We only need to use this for new imagemaps
//These will delete any imagemaps of the same name and override too.
