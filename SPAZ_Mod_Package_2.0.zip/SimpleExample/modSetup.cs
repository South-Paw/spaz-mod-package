//Loaded before any scripts execute.
//Just leave this blank
$AllowDebugSpawning = true; //ctrl-s to spawn ship designs.

$CurrentModData = new ScriptObject()
{
};


























