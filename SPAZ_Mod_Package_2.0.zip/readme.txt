Place the files in this folder in your Mods directory where SPAZ is installed

There should be a Halloween and WinterHoliday Mod in there already.